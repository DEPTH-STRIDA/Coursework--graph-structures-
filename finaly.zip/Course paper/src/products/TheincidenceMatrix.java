package products;

public class TheincidenceMatrix {
    //���� ������� �������������.
    private static int Connection;
    private static int maxLongInc[];
    private static String Inc[][];
    private static int justLongInc[][]; 
    private static int IndInc[][];
    private static String ProbInc[][];
    
    //������� � ������� ��� ������� � ����� ����� ������.
    public static void set_Connection(int a){
        Connection=a;
    }
    public static int get_Connection(){
        return Connection;
    }
    public static void set_long_maxLongInc (int a){
        maxLongInc=new int [a];    
    }
    public static void set_maxLongInc (int[] a){
        maxLongInc=a;
    }
    public static int[] get_maxLongInc(){
        return maxLongInc;
    }
    
    public static void set_long_Inc(int a){
        Inc=new String [a][a];    
    }
    public static void set_Inc(String[][] a){
        Inc=a;
    }
    public static String[][] get_Inc(){
        return Inc;
    }
    
    public static void set_long_justLongInc(int a){
        justLongInc=new int [a][a];    
    }
    public static void set_justLongInc(int[][] a){
        justLongInc=a;
    }
    public static int[][] get_justLongInc(){
        return justLongInc;
    }
    
    public static void set_long_IndInc(int a){
        IndInc=new int [a][a];    
    }
    public static void set_IndInc(int[][] a){
        IndInc=a;
    }
    public static int[][] get_IndInc(){
        return IndInc;
    }
    
     public static void set_long_ProbInc(int a){
        ProbInc=new String [a][a];    
    }
    public static void set_ProbInc(String[][] a){
        ProbInc=a;
    }
    public static String[][] get_ProbInc(){
        return ProbInc;
    }
}
