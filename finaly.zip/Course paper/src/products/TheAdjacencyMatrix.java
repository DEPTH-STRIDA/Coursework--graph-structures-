package products;

public class TheAdjacencyMatrix {
    //���� ������� ���������.
    private static int maxLongAdj[];
    private static String Adj[][];
    private static int justLongAdj[][];
    private static int IndAdj[][];
    private static String ProbAdj[][];
    
    //������� � ������� ��� ������� � ����� ����� ������.
    public static void set_long_maxLongAdj (int a){
        maxLongAdj=new int [a];    
    }
    public static void set_maxLongAdj (int[] a){
        maxLongAdj=a;
    }
    public static int[] get_maxLongAdj(){
        return maxLongAdj;
    }
    
    public static void set_long_Adj(int a){
        Adj=new String [a][a];    
    }
    public static void set_Adj(String[][] a){
        Adj=a;
    }
    public static String[][] get_namesOfNodes(){
        return Adj;
    }
    
    public static void set_long_justLongAdj(int a){
        justLongAdj=new int [a][a];    
    }
    public static void set_justLongAdj(int[][] a){
        justLongAdj=a;
    }
    public static int[][] get_justLongAdj(){
        return justLongAdj;
    }
    
    public static void set_long_IndAdj(int a){
        IndAdj=new int [a][a];    
    }
    public static void set_IndAdj(int[][] a){
        IndAdj=a;
    }
    public static int[][] get_IndAdj(){
        return IndAdj;
    }
    
     public static void set_long_ProbAdj(int a){
        ProbAdj=new String [a][a];    
    }
    public static void set_ProbAdj(String[][] a){
        ProbAdj=a;
    }
    public static String[][] get_ProbAdj(){
        return ProbAdj;
    }
}
