package products;

public class Graph {
    //���� �����.
    private static int Number_of_nodes;
    private static String associations[][];
    private static String namesOfNodes[];
    private static boolean graph=false;
    
    //������� � ������� ��� ������� � ����� ����� ������.
    public static boolean get_graph(){
        return graph;
    }
    public static void set_graph(boolean a){
        graph=a;
    }
    public static void set_Number_of_nodes (int a){
        Number_of_nodes=a;
    }
    public static int get_Number_of_nodes (){
        return Number_of_nodes;
    }

    public static void set_long_associations (int a){
        associations=new String [a][a];    
    }
    public static void set_associations (String[][] a){
        associations=a;
    }
    public static String[][] get_associations(){
        return associations;
    }
    public static void set_long_namesOfNodes(int a){
        namesOfNodes=new String [a];    
    }
    public static void set_namesOfNodes(String[] a){
        namesOfNodes=a;
    }
    public static String[] get_namesOfNodes(){
        return namesOfNodes;
    }
}
