package products;

public class Description {
    
    //���� ��������.
    private static boolean description=false;
    private static String descriptionNotes[];
    private static String descriptionAssociations[][];
    
    //������� � ������� ��� ������� � ����� ����� ������.
    public static boolean get_description(){
        return description;
    }
    public static void set_description(boolean a){
        description=a;
    }
    public static void set_long_descriptionAssociations (int a){
        descriptionAssociations=new String [a][a];    
    }
    public static void set_descriptionAssociations (String[][] a){
        descriptionAssociations=a;
    }
    public static String[][] get_descriptionAssociations(){
        return descriptionAssociations;
    }
    public static void set_one_descriptionAssociations(String a,int b, int c){
        descriptionAssociations[b][c]=a;
    }
    public static String get_one_descriptionAssociations(int a, int b){
        return descriptionAssociations[a][b];
    }
    public static void set_long_descriptionNotes(int a){
        descriptionNotes=new String [a];    
    }
    public static void set_descriptionNotes(String[] a){
        descriptionNotes=a;
    }
    public static String[] get_descriptionNotes(){
        return descriptionNotes;
    }
    public static void set_one_descriptionNotes (String a,int b){
        descriptionNotes[b]=a;
    }
    public static String get_one_descriptionNotes(int a){
        return descriptionNotes[a];
    }
}
