package course.paper;

public interface GraphBuilder {
    public void Enter ();
    public void AddDeleteNote ();
    public void AddDeleteEdge ();
    public void Change ();
    public void Print ();
}
