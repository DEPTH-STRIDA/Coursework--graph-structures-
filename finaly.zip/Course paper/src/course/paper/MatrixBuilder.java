package course.paper;

public interface MatrixBuilder {
    public void Fill_in_matrix();
    public void Counting_lengths();
    public void Creating_gaps();
    public void Print_Matrix();  
}
