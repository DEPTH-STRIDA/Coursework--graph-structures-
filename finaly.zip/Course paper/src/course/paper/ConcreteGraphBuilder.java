package course.paper;

import static course.paper.UsefulFunctions.*;
import java.util.Scanner;
import static products.Description.*;
import static products.Graph.*;

public class ConcreteGraphBuilder implements GraphBuilder {
private static int Number_of_nodes;
private static String namesOfNodes[];
private static String associations[][];
private static String descriptionNotes[];
private static String descriptionAssociations[][];
private static int countOfNew;
private static int deletingNode;
    
    @Override
    public void Enter() {
    set_graph(true);
    String nowLine;
    boolean Cycle=true;
    Scanner in = new Scanner(System.in);
    while (Cycle==true){
            System.out.println("");
            System.out.println("������� ���������� �����:");
            nowLine=in.nextLine();
            if (isNumeric(nowLine)==true){
               Number_of_nodes=(Integer.parseInt (nowLine));
               Cycle=false;
            }
         }
    System.out.println("�� ����� "+ Number_of_nodes);
    namesOfNodes = new String[Number_of_nodes];
    associations=new String[Number_of_nodes][Number_of_nodes];
    descriptionNotes=new String [Number_of_nodes];
    descriptionAssociations=new String [Number_of_nodes][Number_of_nodes];
    set_long_namesOfNodes(Number_of_nodes);
    set_long_associations(Number_of_nodes);
    set_long_descriptionAssociations(Number_of_nodes);
    set_long_descriptionNotes(Number_of_nodes);

    for(int i=0; i<Number_of_nodes; i++){    
           if(i==0){
               namesOfNodes[i]=enteringString("\n������� ����� �����.");
               } 
           else {
               namesOfNodes[i]=enteringString("\n������� ����� �����.");
           }
       }  
       System.out.println("�� ����� ");  
       for (int i=0; i<Number_of_nodes; i++){  
           System.out.print(namesOfNodes[i]+"; ");
       }
       System.out.println("");
       for (int i=0;i<Number_of_nodes;i++){
           for (int k=0;k<Number_of_nodes;k++){
               if (i!=k){
                   associations[i][k]=enteringString("\n������� ����� �� "+namesOfNodes[i]+" � "+namesOfNodes[k]+". ������� ����, ����� �� ��������� �����.");
                   if ("0".equals(associations[i][k])){
                       associations[i][k]="";
                       System.out.println("����� �� \""+namesOfNodes[i]+"\" � \""+namesOfNodes[k]+"\" ���.");}
                   else{
                       System.out.println("�� ����� "+associations[i][k]);
                   }
               }
           }
       }
       set_Number_of_nodes(Number_of_nodes);
       set_associations(associations);
       set_namesOfNodes(namesOfNodes);   
       for (int k=0;k<Number_of_nodes;k++)
       {if(k<Number_of_nodes)
       {
           descriptionNotes[k]="";
       }
       }
       for (int i=0;i<Number_of_nodes;i++) 
       {
           for (int j=0;j<Number_of_nodes;j++) 
           {   
               if (i!=j){
                   if (!"".equals(associations[i][j])) {
                       descriptionAssociations[i][j]="";
                   }
               }
           }
       } 
       set_descriptionAssociations(descriptionAssociations);
       set_descriptionNotes(descriptionNotes);
    }

    @Override
    public void AddDeleteNote() {
        String newnamesOfNodes[];
        String newassociations[][];
        String newDESOfNodes[];
        String newDESofAss[][];
        Scanner in = new Scanner(System.in);
         if (get_graph()==false){
             System.out.println(""); 
             System.out.println((char) 27 + "[31m������ ������� ����! " + (char)27 + "[0m");
         }
         else{
             boolean cycle=true;
             String nowline;
             while (cycle==true){
                 System.out.println(""); 
                 System.out.println("��� �� ������ �������? 0- �������� ����, 1- ������� ����, 2-�����");   
                 nowline=in.nextLine();
                 
                 if (itFits(nowline,0,2)==true){
                     if (Integer.parseInt (nowline)==0){
         ////////////////////////////////////////////���������� ����//////////////////////////////////////////////
                         System.out.print("\n");
                         boolean Cycle1=true; 
                         while (Cycle1==true){
                 System.out.println(""); 
                 System.out.println("������� �������� �����?"); 
                 nowline=in.nextLine();
                 if (isNumeric(nowline)==true){
                     countOfNew=Integer.parseInt (nowline);
                     Cycle1=false;
                 }                   
             }
             newnamesOfNodes=new String[Number_of_nodes+countOfNew]; 
             newassociations=new String [Number_of_nodes+countOfNew][Number_of_nodes+countOfNew];
             newDESOfNodes=new String[Number_of_nodes+countOfNew];
             newDESofAss=new String [Number_of_nodes+countOfNew][Number_of_nodes+countOfNew];  
         
             for (int i=0;i<Number_of_nodes;i++){
                 newnamesOfNodes[i]=namesOfNodes[i];
                 newDESOfNodes[i]=descriptionNotes[i];
             }
                   
             for (int i=Number_of_nodes;i<Number_of_nodes+countOfNew;i++){
                 if(i==Number_of_nodes){
                     newnamesOfNodes[i]=enteringString("\n������� ����� �����.");
                     newDESOfNodes[i]="";} 
                 else{
                     newnamesOfNodes[i]=enteringString("\n������� ����� �����.");
                 }                           
             }
             for (int i=0;i<Number_of_nodes;i++){
                 for (int k=0;k<Number_of_nodes;k++){
                     newassociations[i][k]=associations[i][k];
                     newDESofAss[i][k]=descriptionAssociations[i][k];                
                 }
             }
        
             for (int i=0;i<Number_of_nodes+countOfNew;i++) {
                 for (int k=0;k<Number_of_nodes+countOfNew;k++){
                     if (i!=k){
                         if(newassociations[i][k]==null){
                             newassociations[i][k]=enteringString("\n������� ����� �� "+newnamesOfNodes[i]+" � "+newnamesOfNodes[k]+", ���� ����� ��� ������� ����.");
                             newDESofAss[i][k]="";
                             if ("0".equals(newassociations[i][k])){
                                 newassociations[i][k]="";
                                 System.out.println("�� ����� "+newassociations[i][k]);
                             }  
                         }
                     }
                 }
             }
             namesOfNodes = new String[Number_of_nodes+countOfNew ]; 
             associations=new String[Number_of_nodes+countOfNew][Number_of_nodes+countOfNew];
             descriptionNotes=new String[Number_of_nodes+countOfNew ];
             descriptionAssociations=new String[Number_of_nodes+countOfNew][Number_of_nodes+countOfNew];
             
             set_long_namesOfNodes(Number_of_nodes+countOfNew );
             set_long_associations(Number_of_nodes+countOfNew);
             set_long_descriptionAssociations(Number_of_nodes+countOfNew);
             set_long_descriptionNotes(Number_of_nodes+countOfNew);  
             
             Number_of_nodes=Number_of_nodes+countOfNew;  //
             associations=newassociations;                //
             namesOfNodes=newnamesOfNodes;
             descriptionNotes=newDESOfNodes;
             descriptionAssociations=newDESofAss;
             
             set_Number_of_nodes(Number_of_nodes);
             set_associations(associations);
             set_namesOfNodes(namesOfNodes);
             set_descriptionNotes(descriptionNotes);
             set_descriptionAssociations(descriptionAssociations);
             
          //////////////////////////////////////�������� ����////////////////////////////////////////////////////                
                     }
                     else{
                         if (Integer.parseInt (nowline)==1){           
             String nowLine;
             boolean Cycle=false; 
              while (Cycle==false){
               System.out.println(""); 
                 System.out.println("������� ������ ����, ������� �� ������ �������."); 
                 nowLine=in.nextLine();
                 if(itFits(nowLine,0,Number_of_nodes-1)==true){
                   deletingNode=Integer.parseInt (nowLine);
                   Cycle=true;
                 }
              }
              countOfNew= Number_of_nodes-1;  //����� ���������� �����
              newnamesOfNodes=new String[countOfNew]; 
              newassociations=new String [countOfNew][countOfNew];
              newDESOfNodes=new String[countOfNew];
              newDESofAss=new String [countOfNew][countOfNew]; 
            
            for (int i=0;i<deletingNode;i++){
                 newnamesOfNodes[i]=namesOfNodes[i];
                 newDESOfNodes[i]=descriptionNotes[i];
             }
            
            for (int i=deletingNode;i<countOfNew;i++) {
                newnamesOfNodes[i]=namesOfNodes[i+1];
                 newDESOfNodes[i]=descriptionNotes[i+1];
            }
            
            for (int x=0;x<deletingNode;x++){
                for (int y=0;y<deletingNode;y++){
                        newassociations[x][y]=associations[x][y];
                        newDESofAss[x][y]=descriptionAssociations[x][y];  
                }     
            }   
         
          for (int x=0;x<Number_of_nodes;x++){
              for (int y=deletingNode;y<Number_of_nodes-1;y++){
                  associations[x][y]=associations[x][y+1];
                  descriptionAssociations[x][y]=descriptionAssociations[x][y+1];
              }
          }  
            
           for (int y=0;y<Number_of_nodes;y++){
              for (int x=deletingNode;x<Number_of_nodes-1;x++){
                  associations[x][y]=associations[x+1][y];
                  descriptionAssociations[x][y]=descriptionAssociations[x+1][y];
              }
          }  
           
           for (int x=0;x<Number_of_nodes-1;x++){
               for (int y=0;y<Number_of_nodes-1;y++){
                   newassociations[x][y]=associations[x][y];
                   newDESofAss[x][y]=descriptionAssociations[x][y];     
               }
           }
              
             namesOfNodes = new String[Number_of_nodes-1]; 
             associations=new String[Number_of_nodes-1][Number_of_nodes-1];
             descriptionNotes=new String[Number_of_nodes-1 ]; 
             descriptionAssociations=new String[Number_of_nodes-1][Number_of_nodes-1];
             
             set_long_namesOfNodes(Number_of_nodes+countOfNew );
             set_long_associations(Number_of_nodes+countOfNew);
             set_long_descriptionAssociations(Number_of_nodes+countOfNew);
             set_long_descriptionNotes(Number_of_nodes+countOfNew);  
             
             associations=newassociations;
             namesOfNodes=newnamesOfNodes;
             descriptionNotes=newDESOfNodes;
             descriptionAssociations=newDESofAss;                 
             Number_of_nodes=Number_of_nodes-1;
             
             set_Number_of_nodes(Number_of_nodes);
             set_associations(associations);
             set_namesOfNodes(namesOfNodes);
             set_descriptionNotes(descriptionNotes);
             set_descriptionAssociations(descriptionAssociations);
             
////////////////////////////////////////////////////////�����////////////////////////////////////////////////////////////////////////////////////            
                         }   
                         else{
                             if (Integer.parseInt (nowline)==2){
                              break;
                             }
                         }
                     }
                 }
             } 
         }
    }

    @Override
    public void AddDeleteEdge() {
    if (get_graph()==false) {
            System.out.println(""); 
                 System.out.println((char) 27 + "[31m������ ������� ����! " + (char)27 + "[0m");}
        else {                
            Scanner in = new Scanner(System.in);
            LoockInd();
            boolean cycle1=true;
            boolean cycle2=true;
            while (cycle1==true){
                System.out.println("\n"+Number_of_nodes+"- �������� �������. \n"+(Number_of_nodes+1)+"- ����� \n������� ������ ���� ���������.");
                String nowLine1=in.nextLine();
                if ((itFits(nowLine1,0,(Number_of_nodes+1))&& (isNumeric(nowLine1)==true))){
                    
                    if (Integer.parseInt (nowLine1)==Number_of_nodes) { LoockInd();}
                    
                    if (Integer.parseInt (nowLine1)==Number_of_nodes+1) {cycle1=false;}
                    
                    if ((Integer.parseInt (nowLine1)!=Number_of_nodes) && (Integer.parseInt (nowLine1)!=Number_of_nodes+1)) {
                          System.out.println("������ ������ ������.");
                          
                          while (cycle2==true) {
                            System.out.println(""); 
                            System.out.println("������� ������ ���� ���������.");
                            String nowLine2=in.nextLine();
                            if (itFits(nowLine2,0,Number_of_nodes-1)==true){
                                if (Integer.parseInt (nowLine2)!=Integer.parseInt (nowLine1)) {
                                     String nowLine3=enteringString("\n������� �����, ���� ������ 0, ����� �� �����.");
                                     if ("0".equals(nowLine3)) {
                                         associations[Integer.parseInt (nowLine1)][Integer.parseInt (nowLine2)]="";
                                         cycle1=false;
                                         cycle2=false;
                                     }
                                     else {associations[Integer.parseInt (nowLine1)][Integer.parseInt (nowLine2)]=nowLine3;cycle1=false;
                                         cycle2=false;}
                                }
                                else 
                                {
                                    System.out.println(""); 
                                    System.out.println((char) 27 + "[31m������� �� ������ ���������! " + (char)27 + "[0m");
                                }
                            } 
                          }
                    }
                }
            }    
           set_associations(associations);
        }
    }

    @Override
    public void Change() {
     
             if (get_graph()==false) {
                 System.out.println(""); 
                 System.out.println((char) 27 + "[31m������ ������� ����! " + (char)27 + "[0m");}
             else {
		Scanner in = new Scanner(System.in);
		System.out.print("\n"); 	
		int Z;
		boolean CH=false;
		String nowLine;
                LoockInd();
		while (CH==false)
		{       
                         System.out.println("");          
                         System.out.println("��� �� ������ ��������? 0-���� 1-�����\n2- ���� �� ������ ������� �������. \n3- �����. ");
			 nowLine=in.nextLine();
                         if (itFits(nowLine,0,3)){
                         Z=Integer.parseInt (nowLine);
			 switch(Z)
			 { 
                             case (0):
                                 boolean Cycle=false; 
                                 while (Cycle==false){
                                      System.out.println("");
                                     System.out.println("������� ������, ���� ����, ��� ��� �� ������ ��������.");  
                                     nowLine=in.nextLine();
                                     if (itFits(nowLine, 0, (Number_of_nodes-1))==true){
                                         namesOfNodes[Integer.parseInt (nowLine)]=enteringString("\n������� ����� ��� ����.");
                                         Cycle=true;
                                     }                         
                                 }
                                 set_namesOfNodes(namesOfNodes);
                                 break;
                                 
			 case (1):
                             String nowLine1;
        boolean Cycle1=false; 
        String nowLine2;      
         while (Cycle1==false){
            System.out.println("������� ������ ���� ���������.");  
             nowLine1=in.nextLine();
             if (HasPath(nowLine1,0,Number_of_nodes-1)==true){
                 System.out.println("������ ������ ������.");
                 while (Cycle1==false){
                     System.out.println("������� ������ ���� ���������.");  
                     nowLine2=in.nextLine();
                     if (itFits(nowLine2,0,(Number_of_nodes-1))==true){
                         if (Integer.parseInt (nowLine2)!=Integer.parseInt (nowLine1)){
                         if (!"".equals(associations[Integer.parseInt (nowLine1)][Integer.parseInt (nowLine2)])){
                            associations[Integer.parseInt (nowLine1)][Integer.parseInt (nowLine2)]=enteringString("\n������� ����� �������� �����.");
                            Cycle1=true;
                         }
                         }
                         else {
                             System.out.println("");
                System.out.println((char) 27 + "[31m������� �� ������ ���������! " + (char)27 + "[0m");
                         }
                     }
                 }
             }
         }
         set_associations(associations);
				 break;
			  case (2):
                              LoockInd();
				  break;
                          case (3):
                              CH=true;
                              break;
                         }	
                         }
		}
	}
    }

    @Override
    public void Print() {
         if (get_graph()==false) {
                 System.out.println(""); 
                 System.out.println((char) 27 + "[31m������ ������� ����! " + (char)27 + "[0m");}
             else {
        boolean ways[]=new boolean[Number_of_nodes];
        
        for (int x=0;x<Number_of_nodes;x++){
            for (int y=0;y<Number_of_nodes;y++){
                if (x!=y){
                    if (!"".equals(associations[x][y])){
                    ways[x]=true;
                    }
                }
            }
        }
        
        for (int x=0;x<Number_of_nodes;x++){
            if (ways[x]==true){
            for (int y=0;y<Number_of_nodes;y++){
                if (x!=y){
                    if (!"".equals(associations[x][y])){
                    System.out.println(namesOfNodes[x]+"-- "+associations[x][y]+" -->"+namesOfNodes[y]);
                    }
                    }
            }
        }
            else {
                System.out.println(namesOfNodes[x]+" ������ �� �����.");
            }
    }
   }
}
}
